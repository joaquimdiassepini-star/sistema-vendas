import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from tkinter import messagebox, filedialog
import sqlite3
import bcrypt
from datetime import datetime
import csv
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import uuid
import threading

class Database:
    def __init__(self):
        self.conn = sqlite3.connect("sistema.db")
        self.cursor = self.conn.cursor()
        self.setup()
    def setup(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY,
            usuario TEXT UNIQUE,
            senha TEXT,
            role TEXT DEFAULT 'user'
        )
        """)
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS vendas (
            id INTEGER PRIMARY KEY,
            venda_id TEXT,
            usuario TEXT,
            produto TEXT,
            valor REAL,
            desconto REAL,
            valor_final REAL,
            created_at TEXT
        )
        """)
        self.conn.commit()

db = Database()

class AuthService:
    @staticmethod
    def hash_senha(senha: str) -> bytes:
        return bcrypt.hashpw(senha.encode(), bcrypt.gensalt())
    @staticmethod
    def verificar(senha: str, hash_armazenado: bytes) -> bool:
        return bcrypt.checkpw(senha.encode(), hash_armazenado)
    @staticmethod
    def login(user: str, senha: str):
        db.cursor.execute("SELECT usuario, senha, role FROM usuarios WHERE usuario=?", (user,))
        res = db.cursor.fetchone()
        if res and AuthService.verificar(senha, res[1]):
            return res[0], res[2]
        return None
    @staticmethod
    def registrar(user: str, senha: str):
        if not user:
            return False, "Usuário obrigatório"
        if len(senha) < 6:
            return False, "Senha deve ter ao menos 6 caracteres"
        try:
            db.cursor.execute(
                "INSERT INTO usuarios (usuario, senha) VALUES (?, ?)",
                (user, AuthService.hash_senha(senha))
            )
            db.conn.commit()
            return True, "Conta criada com sucesso"
        except sqlite3.IntegrityError:
            return False, "Usuário já existe"
        except Exception as e:
            return False, f"Erro inesperado: {e}"

class InputField:
    def __init__(self, parent, label, placeholder="", is_password=False):
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill=X, pady=5)
        ttk.Label(self.frame, text=label).pack(anchor="w")
        self.var = ttk.StringVar()
        self.entry = ttk.Entry(self.frame, textvariable=self.var)
        self.entry.pack(fill=X)
        self.placeholder = placeholder
        self.is_password = is_password
        self.default_fg = self.entry.cget("foreground")
        self._add_placeholder()
        self.entry.bind("<FocusIn>", self._clear_placeholder)
        self.entry.bind("<FocusOut>", self._add_placeholder)
        self.error = ttk.Label(self.frame, text="", foreground="red")
        self.error.pack(anchor="w")
    def _clear_placeholder(self, e=None):
        if self.entry.get() == self.placeholder:
            self.entry.delete(0, END)
            self.entry.config(foreground=self.default_fg)
            if self.is_password:
                self.entry.config(show="*")
    def _add_placeholder(self, e=None):
        if not self.entry.get():
            self.entry.insert(0, self.placeholder)
            self.entry.config(foreground="gray")
            if self.is_password:
                self.entry.config(show="")
    def get(self):
        val = self.entry.get()
        return "" if val == self.placeholder else val
    def set_error(self, msg):
        self.entry.config(bootstyle="danger")
        self.error.config(text=msg)
    def clear_error(self):
        self.entry.config(bootstyle="")
        self.error.config(text="")

class App:
    def __init__(self):
        self.usuario = None
        self.role = None
        self.lista = []
        self.login_screen()

    def login_screen(self):
        self.win = ttk.Window(themename="flatly")
        self.win.title("Login")
        frame = ttk.Frame(self.win, padding=20)
        frame.pack(fill=BOTH, expand=True)
        ttk.Label(frame, text="Sistema de Vendas", font=("Arial", 16, "bold")).pack(pady=10)
        self.user_input = InputField(frame, "Usuário", "Digite seu usuário")
        self.pass_input = InputField(frame, "Senha", "Digite sua senha", True)
        ttk.Button(frame, text="Entrar", bootstyle=SUCCESS, command=self.login).pack(fill=X, pady=5)
        ttk.Button(frame, text="Cadastrar", bootstyle=INFO, command=self.register_screen).pack(fill=X)
        self.win.bind("<Return>", lambda e: self.login())
        self.win.mainloop()

    def login(self):
        u, p = self.user_input.get(), self.pass_input.get()
        self.user_input.clear_error()
        self.pass_input.clear_error()
        if not u:
            self.user_input.set_error("Informe usuário")
            return
        if not p:
            self.pass_input.set_error("Informe senha")
            return
        res = AuthService.login(u, p)
        if res:
            self.usuario, self.role = res
            self.win.destroy()
            self.main_screen()
        else:
            self.pass_input.set_error("Login inválido")

    def register_screen(self):
        win = ttk.Toplevel(self.win)
        win.title("Cadastro")
        frame = ttk.Frame(win, padding=20)
        frame.pack(fill=BOTH, expand=True)
        user_input = InputField(frame, "Usuário", "Novo usuário")
        pass_input = InputField(frame, "Senha", "Senha", True)
        conf_input = InputField(frame, "Confirmar", "Repita senha", True)
        def salvar():
            user_input.clear_error()
            pass_input.clear_error()
            conf_input.clear_error()
            if pass_input.get() != conf_input.get():
                conf_input.set_error("Senhas não conferem")
                return
            ok, msg = AuthService.registrar(user_input.get(), pass_input.get())
            if ok:
                messagebox.showinfo("Sucesso", msg)
                win.destroy()
            else:
                messagebox.showerror("Erro", msg)
        ttk.Button(frame, text="Salvar", bootstyle=SUCCESS, command=salvar).pack(fill=X)
        win.bind("<Return>", lambda e: salvar())

    def main_screen(self):
        self.root = ttk.Window(themename="flatly")
        self.root.title(f"Loja - {self.usuario} ({self.role})")
        f = ttk.Frame(self.root, padding=10)
        f.pack(fill=BOTH, expand=True)
        self.produto_input = InputField(f, "Produto", "Ex: Camiseta")
        self.valor_input = InputField(f, "Valor", "0")
        self.desc_input = InputField(f, "Desconto (%)", "0")
        self.tree = ttk.Treeview(f, columns=("Produto","Valor","Desconto","Final"), show="headings", selectmode="extended")
        for col in ("Produto","Valor","Desconto","Final"):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor=CENTER)
        self.tree.pack(fill=BOTH, expand=True, pady=10)
        self.tree.bind("<Double-1>", self.editar_item)
        ttk.Button(f, text="Adicionar", bootstyle=SUCCESS, command=self.add_item).pack(fill=X)
        ttk.Button(f, text="Remover Selecionados", bootstyle=DANGER, command=self.remove_item).pack(fill=X)
        ttk.Button(f, text="Finalizar Selecionados", bootstyle=PRIMARY, command=self.finalizar).pack(fill=X)
        ttk.Button(f, text="Exportar CSV", bootstyle=INFO, command=self.export_csv_threaded).pack(fill=X)
        self.total_label = ttk.Label(f, text="Total: R$ 0.00", font=("Arial", 12, "bold"))
        self.total_label.pack(pady=5)
        ttk.Button(f, text="Histórico", bootstyle=SECONDARY, command=self.historico).pack(fill=X)
        ttk.Button(f, text="Dashboard", bootstyle=WARNING, command=self.dashboard_threaded).pack(fill=X, pady=5)
        self.produto_input.entry.bind("<Return>", lambda e: self.valor_input.entry.focus())
        self.valor_input.entry.bind("<Return>", lambda e: self.desc_input.entry.focus())
        self.desc_input.entry.bind("<Return>", lambda e: self.add_item())
        self.root.mainloop()

    def calcular_total(self):
        total = sum(item["valor_final"] for item in self.lista)
        self.total_label.config(text=f"Total: R$ {total:.2f}")

    def add_item(self):
        produto = self.produto_input.get()
        valor_str = self.valor_input.get() or "0"
        desconto_str = self.desc_input.get() or "0"
        valid = True
        if not produto.strip():
            self.produto_input.set_error("Produto obrigatório")
            valid = False
        else:
            self.produto_input.clear_error()
        try:
            valor = float(valor_str)
            if valor < 0:
                raise ValueError
            self.valor_input.clear_error()
        except ValueError:
            self.valor_input.set_error("Valor inválido")
            valid = False
        try:
            desconto = float(desconto_str)
            if not (0 <= desconto <= 100):
                raise ValueError
            self.desc_input.clear_error()
        except ValueError:
            self.desc_input.set_error("Desconto 0-100")
            valid = False
        if not valid:
            return
        valor_final = valor * (1 - desconto/100)
        item = {"produto": produto, "valor": valor, "desconto": desconto, "valor_final": valor_final}
        self.lista.append(item)
        self.tree.insert("", END, values=(produto, f"{valor:.2f}", f"{desconto:.2f}", f"{valor_final:.2f}"))
        self.calcular_total()
        self.produto_input.entry.delete(0, END)
        self.valor_input.entry.delete(0, END)
        self.desc_input.entry.delete(0, END)
        self.produto_input.entry.focus()

    def editar_item(self, event):
        sel = self.tree.selection()
        if not sel: return
        idx = self.tree.index(sel[0])
        item = self.lista[idx]
        win = ttk.Toplevel(self.root)
        win.title("Editar Item")
        frame = ttk.Frame(win, padding=10)
        frame.pack()
        prod = InputField(frame, "Produto")
        prod.entry.insert(0, item["produto"])
        val = InputField(frame, "Valor")
        val.entry.insert(0, str(item["valor"]))
        desc = InputField(frame, "Desconto")
        desc.entry.insert(0, str(item["desconto"]))
        def salvar():
            try:
                valor = float(val.get())
                desconto = float(desc.get())
                if valor < 0 or not (0 <= desconto <= 100):
                    raise ValueError
            except ValueError:
                messagebox.showerror("Erro", "Valor ou desconto inválido")
                return
            valor_final = valor * (1 - desconto/100)
            self.lista[idx] = {"produto": prod.get(), "valor": valor, "desconto": desconto, "valor_final": valor_final}
            self.tree.item(sel, values=(prod.get(), f"{valor:.2f}", f"{desconto:.2f}", f"{valor_final:.2f}"))
            self.calcular_total()
            win.destroy()
        ttk.Button(frame, text="Salvar", bootstyle=SUCCESS, command=salvar).pack()
        win.bind("<Return>", lambda e: salvar())

    def remove_item(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Aviso", "Selecione item(s) para remover")
            return
        if messagebox.askyesno("Confirmação", f"Remover {len(sel)} item(s)?"):
            for s in reversed(sel):
                idx = self.tree.index(s)
                self.tree.delete(s)
                self.lista.pop(idx)
            self.calcular_total()

    def finalizar(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Aviso", "Selecione item(s) a finalizar")
            return
        venda_id = str(uuid.uuid4())
        for s in reversed(sel):
            idx = self.tree.index(s)
            item = self.lista[idx]
            db.cursor.execute("""
                INSERT INTO vendas (venda_id, usuario, produto, valor, desconto, valor_final, created_at)
                VALUES (?,?,?,?,?,?,?)
            """, (venda_id, self.usuario, item["produto"], item["valor"], item["desconto"], item["valor_final"], datetime.now()))
            self.tree.delete(s)
            self.lista.pop(idx)
        db.conn.commit()
        self.calcular_total()
        messagebox.showinfo("Sucesso", "Item(s) finalizado(s)")

    def export_csv(self):
        if not self.lista:
            messagebox.showwarning("Aviso", "Nenhum item para exportar")
            return
        file = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files","*.csv")], title="Salvar lista de itens")
        if not file:
            return
        with open(file,"w",newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["Produto","Valor","Desconto","Final"])
            for i in self.lista:
                w.writerow([i["produto"], f"{i['valor']:.2f}", f"{i['desconto']:.2f}", f"{i['valor_final']:.2f}"])
        messagebox.showinfo("Exportado", "Arquivo CSV salvo com sucesso")

    def export_csv_threaded(self):
        threading.Thread(target=self.export_csv, daemon=True).start()

    def historico(self):
        win = ttk.Toplevel(self.root)
        win.title("Histórico de Vendas")
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill=BOTH, expand=True)
        tree = ttk.Treeview(frame, columns=("Venda","Usuário","Produto","Valor Final","Data"), show="headings")
        for col in ("Venda","Usuário","Produto","Valor Final","Data"):
            tree.heading(col,text=col)
            tree.column(col, width=120)
        tree.pack(fill=BOTH, expand=True)
        db.cursor.execute("SELECT venda_id, usuario, produto, valor_final, created_at FROM vendas ORDER BY created_at DESC")
        for row in db.cursor.fetchall():
            tree.insert("",END,values=row)
        def export_hist():
            file = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files","*.csv")], title="Salvar histórico")
            if not file: return
            with open(file,"w",newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(["Venda","Usuário","Produto","Valor Final","Data"])
                for row in db.cursor.execute("SELECT venda_id, usuario, produto, valor_final, created_at FROM vendas ORDER BY created_at DESC"):
                    w.writerow(row)
            messagebox.showinfo("Exportado","Histórico exportado com sucesso")
        ttk.Button(frame,text="Exportar Histórico",bootstyle=INFO,command=export_hist).pack(fill=X)

    def dashboard(self):
        win = ttk.Toplevel(self.root)
        win.title("Dashboard")
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill=BOTH, expand=True)
        fig = Figure(figsize=(7,5))
        ax = fig.add_subplot(111)
        db.cursor.execute("SELECT DATE(created_at), SUM(valor_final), COUNT(*) FROM vendas GROUP BY DATE(created_at)")
        data = db.cursor.fetchall()
        if data:
            dates, totals, counts = zip(*data)
            ax.bar(dates, totals, color='skyblue', label='Total R$')
            for i, c in enumerate(counts):
                ax.text(i, totals[i], str(c), ha='center', va='bottom', fontsize=8)
            ax.set_title("Vendas por Data")
            ax.set_ylabel("Total (R$)")
            ax.set_xlabel("Data")
            ax.legend()
            ax.tick_params(axis='x', rotation=45)
        else:
            ax.text(0.5,0.5,"Sem dados",ha="center", va="center")
        canvas = FigureCanvasTkAgg(fig, master=frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=BOTH, expand=True)

    def dashboard_threaded(self):
        threading.Thread(target=self.dashboard, daemon=True).start()

App()